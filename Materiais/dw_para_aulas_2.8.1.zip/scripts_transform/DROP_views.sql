DROP VIEW v_last_iteration_info;
DROP VIEW v_data_with_problems;
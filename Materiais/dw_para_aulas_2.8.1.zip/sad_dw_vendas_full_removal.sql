@@scripts_extract\DROP_tables
@@scripts_extract\DROP_packages
@@scripts_transform\DROP_tables
@@scripts_transform\DROP_sequences
@@scripts_transform\DROP_packages
@@scripts_transform\DROP_views
@@scripts_load\DROP_tables
@@scripts_load\DROP_sequences
@@scripts_load\DROP_packages
@@scripts_extras\log\DROP_tables
@@scripts_extras\log\DROP_packages
@@scripts_extras\error_codes\DROP_packages



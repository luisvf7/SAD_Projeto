@@CREATE_data_tables
@@CREATE_info_tables
@@CREATE_external_tables
@@CREATE_package_pck_extract

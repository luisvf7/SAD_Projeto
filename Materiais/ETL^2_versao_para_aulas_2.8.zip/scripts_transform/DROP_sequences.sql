DROP SEQUENCE seq_tel_iteration;
DROP SEQUENCE seq_tel_screen;
DROP SEQUENCE seq_tel_source;
DROP SEQUENCE seq_tel_date;


CREATE TABLE t_log_etl(
	id			NUMBER(10),
	log_text		VARCHAR2(500),
	execution_start	TIMESTAMP
);



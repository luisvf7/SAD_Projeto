@@CREATE_data_tables
@@CREATE_external_tables.sql
@@CREATE_sequences
@@CREATE_package_pck_load

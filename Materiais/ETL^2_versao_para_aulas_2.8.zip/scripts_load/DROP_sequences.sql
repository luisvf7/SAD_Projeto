DROP SEQUENCE seq_dim_store;
DROP SEQUENCE seq_dim_product;
DROP SEQUENCE seq_dim_promotion;


